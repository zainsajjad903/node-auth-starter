function showform(type) {
  document.getElementById("bannerBox").classList.add("shrink");
  document.getElementById("formBox").classList.add("expand");
  document.getElementById("signupForm").classList.add("hidden");
  document.getElementById("loginForm").classList.add("hidden");

  if (type === "signup") document.getElementById("signupForm").classList.remove("hidden");
  else if (type === "login") document.getElementById("loginForm").classList.remove("hidden");
}

function goBack() {
  document.getElementById("bannerBox").classList.remove("shrink");
  document.getElementById("formBox").classList.remove("expand");
  document.getElementById("signupForm").classList.add("hidden");
  document.getElementById("loginForm").classList.add("hidden");
}

document.querySelector('#signupForm button').onclick = async function () {
  const name = document.querySelector("#signupForm input[name='name']").value;
  const email = document.querySelector("#signupForm input[name='email']").value;
  const password = document.querySelector("#signupForm input[name='password']").value;
  const confirm = document.querySelector("#signupForm input[name='confirm']").value;

  if (password !== confirm) return alert("Passwords don't match");

  const res = await fetch("/signup", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, email, password })
  });

  const data = await res.json();
  alert(data.message);
};

document.querySelector('#loginForm button').onclick = async function () {
  const email = document.querySelector("#loginForm input[name='email']").value;
  const password = document.querySelector("#loginForm input[name='password']").value;

  const res = await fetch("/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password })
  });

  const data = await res.json();
  if (res.ok) {
    alert("Login Success");
  } else {
    document.getElementById("msg").innerText = data.message;
    document.getElementById("msg").style.display = "block";
  }
};
